import {Injectable} from '@angular/core';
import { environment } from '../environments/environment';

@Injectable()
export class AppConstants {
  constructor() {
  }

  /* API HEADERS */

  /* API END POINTS */
  public SERVER = 'http://localhost:3000/';
  public API_URL = 'adwords/api/';
  public FINAL_URL = this.SERVER + this.API_URL;
  public AUTHORIZATION = 'dummy_value';
}