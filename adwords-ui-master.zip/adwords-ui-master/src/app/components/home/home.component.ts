import { Component, OnInit, OnDestroy } from '@angular/core';
import { AdwordsApiService } from '../../web-service/adwords-api.service';
import { DataStorageService } from '../../web-service/data-storage.service';
import { Subscription } from 'rxjs';
import { FormControl, FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {

  /* private */
  private getCampaignsSubscription: Subscription;
  private getReportFieldsSubscription: Subscription;
  private downloadCriteriaReportWithAwqlSubscription: Subscription;

  /* public */
  public getCampaignsData;
  public getReportFieldsData;
  public adwordsForm;
  public region: string;
  public status: string;

  constructor(private adwordsApiService: AdwordsApiService,
    private dataStorageService: DataStorageService,
    private formBuilder: FormBuilder) {
    /* Initiliztion */
    this.getCampaignsData = {
      "code": '',
      "data": [],
      "message": ""
    }

    this.getReportFieldsData = {
      "code": '',
      "data": [],
      "message": ""
    }

    this.region = 'India';
    this.status = 'ENABLED'
  }

  ngOnInit() {
    // this.getCampaignsAPI();
    // this.getReportFieldsAPI();
    this.getCampaignsData = this.dataStorageService.getGetCampaignsData();
    this.getReportFieldsData = this.dataStorageService.getGetReportFieldsData();
    this.initializingForm();
  }

  getCampaignsAPI() {
    this.adwordsApiService.GetCampaigns({});
    this.getCampaignsSubscription = this.dataStorageService.getCampaignsDataChanged.subscribe(
      (getCampaignsData) => {
        console.log(getCampaignsData);
        this.getCampaignsData = getCampaignsData;
      }
    );
  }

  getReportFieldsAPI() {
    this.adwordsApiService.GetReportFields({});
    this.getReportFieldsSubscription = this.dataStorageService.getReportFieldsDataChanged.subscribe(
      (getReportFields) => {
        console.log(getReportFields);
        this.getReportFieldsData = getReportFields;
      }
    );
  }

  initializingForm() {
    // this.adwordsForm = new FormGroup({
    //   'startDate': new FormControl(null, Validators.required),
    //   'endDate': new FormControl(null, Validators.required),
    //   'campaign': new FormControl(null, Validators.required),
    //   'reportFields': new FormControl(null, Validators.required)
    // });

    // this.adwordsForm = new FormGroup({
    //   'startDate': new FormControl(null, Validators.required),
    //   'endDate': new FormControl(null, Validators.required),
    //   'campaign': new FormControl(null, Validators.required),
    //   'reportFields': new FormControl(null, Validators.required)
    // });

    const campaignControls = this.getCampaignsData.data.map(c => new FormControl(false));
    const reportFieldControls = this.getReportFieldsData.data.map(c => new FormControl(false));

    console.log(campaignControls);
    console.log(reportFieldControls);



    this.adwordsForm = this.formBuilder.group({
      startDate: [''],
      endDate: [''],
      region: ['india'],
      status: ['enabled'],
      campaign: new FormArray(campaignControls),
      reportFields: new FormArray(reportFieldControls),
    });
  }

  adwordsFormSubmit() {
    const startDate = this.adwordsForm.value.startDate;
    const endDate = this.adwordsForm.value.endDate;
    const region = this.adwordsForm.value.region;
    const campaign = this.adwordsForm.value.campaign
      .map((v, i) => v ? {
        'campaignName': this.getCampaignsData.data[i].campaignName,
        'campaignId': this.getCampaignsData.data[i].campaignId,
        'status': this.getCampaignsData.data[i].Status
      } : null)
      .filter(v => v !== null);

    const reportFields = this.adwordsForm.value.reportFields
      .map((v, i) => v ? {
        'fieldName': this.getReportFieldsData.data[i].fieldName,
        'displayFieldName': this.getReportFieldsData.data[i].displayFieldName,
        'xmlAttributeName': this.getReportFieldsData.data[i].xmlAttributeName,
        'fieldType': this.getReportFieldsData.data[i].fieldType,
        'fieldBehavior': this.getReportFieldsData.data[i].fieldBehavior
      } : null)
      .filter(v => v !== null);
    // const campaign = this.adwordsForm.value.campaign;
    // const reportFields = this.adwordsForm.value.reportFields;
    console.log(startDate);
    console.log(endDate);
    console.log(region)
    console.log(campaign);
    console.log(reportFields);

    this.adwordsApiService.DownloadCriteriaReportWithAwql({
      campaigns: campaign,
      reportFields,
      dateRange: {
        startDate,
        endDate
      }
    });

    this.downloadCriteriaReportWithAwqlSubscription = this.dataStorageService.downloadCriteriaReportWithAwqlDataChanged.subscribe(
      (downloadCriteriaReportWithAwqlData) => {
        this.downloadCriteriaReportWithAwqlSubscription.unsubscribe();
        // downloadCriteriaReportWithAwqlData.data.downloadLink;
        console.log(downloadCriteriaReportWithAwqlData.data.downloadLink);
        var fileUrl = downloadCriteriaReportWithAwqlData.data.downloadLink;
        window.open(fileUrl, '_blank');
      }
    );
  }

  onRegionRadio(event) {
    console.log('onRegionRadio');

    // console.log('event.target.value');
    console.log(event.target.value);
    if (event.target.value == 'india') {
      this.region = 'India';
    }
    if (event.target.value == 'international') {
      this.region = 'International'
    }
  }

  onStatusRadio(event) {
    console.log('onStatusRadio');

    // console.log('event.target.value');
    console.log(event.target.value);
    if (event.target.value == 'enabled') {
      this.status = 'ENABLED';
    }
    if (event.target.value == 'paused') {
      this.status = 'PAUSED'
    }
  }

  ngOnDestroy() {

    if (this.getCampaignsSubscription != undefined) {
      this.getCampaignsSubscription.unsubscribe();
    }

    if (this.getReportFieldsSubscription != undefined) {
      this.getReportFieldsSubscription.unsubscribe();
    }
  }

}
