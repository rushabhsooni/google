import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormArray } from '@angular/forms';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  form: FormGroup;

  // data which we will eventually recieve from API
  orders = [];
  constructor(private formBuilder: FormBuilder) {

    setTimeout(function () {
      this.orders = [
        { id: 100, name: 'order 1' },
        { id: 200, name: 'order 2' },
        { id: 300, name: 'order 3' },
        { id: 400, name: 'order 4' }
      ]
      // alert("Hello")
      const controls = this.orders.map( c => new FormControl(false));

      // const controls = this.orders.map(c => new FormControl(false));
      controls[0].setValue(true); // Set the first checkbox to true (checked)
      console.log(controls);
      
      this.form = this.formBuilder.group({
        orders: new FormArray(controls),
        name: ['test']
      });
    }, 5000);
    
  }

  ngOnInit() {
    // modularization mode
  }

  submit() {
    console.log(this.form.value);
    // if value is true the insert their corresponding value in array else not
    const selectedOrderIds = this.form.value.orders
      .map((v, i) => v ? this.orders[i].id : null)
      .filter(v => v !== null);
    console.log(selectedOrderIds);
    console.log(this.form.value.name);
    
  }

}
