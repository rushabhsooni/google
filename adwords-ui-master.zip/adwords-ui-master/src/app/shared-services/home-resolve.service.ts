import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { AdwordsApiService } from '../web-service/adwords-api.service';
import { DataStorageService } from '../web-service/data-storage.service';

@Injectable({
  providedIn: 'root'
})
export class HomeResolveService implements Resolve<{}> {

  public getCampaignsSubscription;
  public getReportFieldsSubscription;

  constructor(private adwordsApiService: AdwordsApiService,
    private dataStorageService: DataStorageService) { }

  resolve(route: ActivatedRouteSnapshot): Promise<{}> | {} {
    this.adwordsApiService.GetCampaigns({});
    this.getCampaignsSubscription = this.dataStorageService.getCampaignsDataChanged.subscribe(
      (getCampaignsData)=>{
        this.adwordsApiService.GetReportFields({});
      }
    );

    let promise = new Promise((resolve, reject) => {
      this.getReportFieldsSubscription = this.dataStorageService.getReportFieldsDataChanged.subscribe(
        (getReportFieldsData) => {
          resolve(getReportFieldsData);
        }
      );
    });
    
    return promise;
  }
}
