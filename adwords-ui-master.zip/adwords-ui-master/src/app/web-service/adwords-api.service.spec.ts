import { TestBed, inject } from '@angular/core/testing';

import { AdwordsApiService } from './adwords-api.service';

describe('AdwordsApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdwordsApiService]
    });
  });

  it('should be created', inject([AdwordsApiService], (service: AdwordsApiService) => {
    expect(service).toBeTruthy();
  }));
});
