import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { AppConstants } from '../app.constants';
import { DataStorageService } from './data-storage.service';

@Injectable({
  providedIn: 'root'
})
export class AdwordsApiService {

  constructor(private httpClient: HttpClient, private appConstants: AppConstants, private dataStorageService: DataStorageService) {}

  GetCampaigns(postParams) {
    const headers = new HttpHeaders()
      .set('authorization', this.appConstants.AUTHORIZATION)
      .append('content-type', 'application/json');
    return this.httpClient.post(this.appConstants.FINAL_URL + 'GetCampaigns/', postParams, {
      headers: headers
    }).subscribe(
      (data) => {
        this.dataStorageService.setGetCampaignsData(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          // console.log("Client-side error occured checkWarrenty.");
        } else {
          // console.log("Server-side error occured checkWarrenty.");
          // var warningModal = JSON.parse(err.error);
          let warningModal;
          try {
            warningModal = JSON.parse(err.error);
          } catch (errorCatch) {
            warningModal = err.error;
          }
          this.dataStorageService.setGetCampaignsData(warningModal);
        }
      }
    );
  }

  DownloadCriteriaReportWithAwql(postParams) {
    const headers = new HttpHeaders()
      .set('authorization', this.appConstants.AUTHORIZATION)
      .append('content-type', 'application/json');
    return this.httpClient.post(this.appConstants.FINAL_URL + 'DownloadCriteriaReportWithAwql/', postParams, {
      headers: headers
    }).subscribe(
      (data) => {
        this.dataStorageService.setDownloadCriteriaReportWithAwqlData(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          // console.log("Client-side error occured checkWarrenty.");
        } else {
          // console.log("Server-side error occured checkWarrenty.");
          // var warningModal = JSON.parse(err.error);
          let warningModal;
          try {
            warningModal = JSON.parse(err.error);
          } catch (errorCatch) {
            warningModal = err.error;
          }
          this.dataStorageService.setDownloadCriteriaReportWithAwqlData(warningModal);
        }
      }
    );
  }

  GetReportFields(postParams) {
    const headers = new HttpHeaders()
      .set('authorization', this.appConstants.AUTHORIZATION)
      .append('content-type', 'application/json');
    return this.httpClient.post(this.appConstants.FINAL_URL + 'GetReportFields/', postParams, {
      headers: headers
    }).subscribe(
      (data) => {
        this.dataStorageService.setGetReportFieldsData(data);
      },
      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          // console.log("Client-side error occured checkWarrenty.");
        } else {
          // console.log("Server-side error occured checkWarrenty.");
          // var warningModal = JSON.parse(err.error);
          let warningModal;
          try {
            warningModal = JSON.parse(err.error);
          } catch (errorCatch) {
            warningModal = err.error;
          }
          this.dataStorageService.setGetReportFieldsData(warningModal);
        }
      }
    );
  }

}
