import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataStorageService {

  /* GetCampaigns */
  private getCampaignsData;
  public getCampaignsDataChanged = new Subject < any > ();

  /* DownloadCriteriaReportWithAwql */
  private downloadCriteriaReportWithAwqlData;
  public downloadCriteriaReportWithAwqlDataChanged = new Subject < any > ();

  /* GetReportFields */
  private getReportFieldsData;
  public getReportFieldsDataChanged = new Subject < any > ();

  constructor() {}

  getGetCampaignsData() {
    return this.getCampaignsData;
  }

  setGetCampaignsData(response) {
    this.getCampaignsData = response;
    this.getCampaignsDataChanged.next(this.getCampaignsData);
  }

  getDownloadCriteriaReportWithAwqlData() {
    return this.downloadCriteriaReportWithAwqlData;
  }

  setDownloadCriteriaReportWithAwqlData(response) {
    this.downloadCriteriaReportWithAwqlData = response;
    this.downloadCriteriaReportWithAwqlDataChanged.next(this.downloadCriteriaReportWithAwqlData);
  }

  getGetReportFieldsData() {
    return this.getReportFieldsData;
  }

  setGetReportFieldsData(response) {
    this.getReportFieldsData = response;
    this.getReportFieldsDataChanged.next(this.getReportFieldsData);
  }
}
